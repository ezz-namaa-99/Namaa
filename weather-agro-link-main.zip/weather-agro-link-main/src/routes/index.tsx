import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Sun, Cloud, Droplets, Wind, Sprout, Calculator, MessageCircle, BookOpen, Leaf, Phone, Send, Headphones, ClipboardList, Trash2 } from "lucide-react";
import { toast, Toaster } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import engineerPhoto from "@/assets/engineer.jpg";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "نماء - المهندس عزالدين الغراسي | خبير وقاية النبات" },
      { name: "description", content: "تطبيق نماء للاستشارات الزراعية: طقس، حاسبة تسميد، سجل زراعي، واستشارة فورية." },
      { name: "viewport", content: "width=device-width, initial-scale=1, maximum-scale=1" },
      { name: "theme-color", content: "#2f6b3a" },
    ],
  }),
});

const WHATSAPP_NUMBER = "966558035449";
const LOG_KEY = "nama_farm_log";

const CROP_RATES: Record<string, { N: number; P: number; K: number; label: string }> = {
  wheat:    { label: "قمح",    N: 150, P: 60,  K: 60 },
  corn:     { label: "ذرة",    N: 200, P: 80,  K: 100 },
  tomato:   { label: "طماطم",  N: 250, P: 120, K: 300 },
  potato:   { label: "بطاطا",  N: 180, P: 100, K: 240 },
  citrus:   { label: "حمضيات", N: 220, P: 90,  K: 180 },
  olive:    { label: "زيتون",  N: 120, P: 50,  K: 120 },
  date:     { label: "نخيل",   N: 300, P: 150, K: 400 },
  cucumber: { label: "خيار",   N: 200, P: 100, K: 250 },
};

const FERT: Record<string, { label: string; n: number; p: number; k: number }> = {
  urea:       { label: "يوريا 46%",          n: 0.46, p: 0,    k: 0 },
  dap:        { label: "DAP (18-46-0)",      n: 0.18, p: 0.46, k: 0 },
  npk_15:     { label: "NPK 15-15-15",       n: 0.15, p: 0.15, k: 0.15 },
  npk_20:     { label: "NPK 20-20-20",       n: 0.20, p: 0.20, k: 0.20 },
  potassium:  { label: "سلفات بوتاسيوم 50%", n: 0,    p: 0,    k: 0.50 },
  ammonium:   { label: "نترات الأمونيوم 33%",n: 0.33, p: 0,    k: 0 },
};

interface Weather {
  temp: number;
  wind: number;
  humidity: number;
  code: number;
  city: string;
}

function weatherInfo(code: number) {
  if (code === 0) return { label: "صافٍ", Icon: Sun };
  if (code <= 3) return { label: "غائم جزئياً", Icon: Cloud };
  if (code <= 48) return { label: "ضباب", Icon: Cloud };
  if (code <= 67) return { label: "أمطار", Icon: Droplets };
  if (code <= 77) return { label: "ثلوج", Icon: Cloud };
  if (code <= 82) return { label: "زخات مطر", Icon: Droplets };
  return { label: "عاصف", Icon: Wind };
}

function getTips(w: Weather | null): string[] {
  if (!w) return [];
  const tips: string[] = [];
  if (w.temp >= 35) tips.push("الحرارة مرتفعة: قم بالري في الصباح الباكر أو بعد الغروب لتقليل التبخر.");
  else if (w.temp <= 10) tips.push("الجو بارد: قلّل الري وراقب المحاصيل الحساسة للصقيع.");
  else tips.push("درجة الحرارة معتدلة: ظروف مناسبة لمعظم العمليات الزراعية.");
  if (w.humidity >= 75) tips.push("رطوبة مرتفعة: راقب ظهور الأمراض الفطرية وتجنب التسميد الورقي.");
  else if (w.humidity <= 30) tips.push("رطوبة منخفضة: زِد كمية الري وفكر في التغطية لحماية التربة.");
  if ([61, 63, 65, 80, 81, 82, 95, 96, 99].includes(w.code))
    tips.push("هناك أمطار متوقعة: أجّل الرش والتسميد لتجنب الجريان السطحي.");
  return tips;
}

function Header() {
  return (
    <header className="relative overflow-hidden" style={{ background: "var(--gradient-hero)" }}>
      <div className="absolute inset-0 opacity-10" style={{ backgroundImage: "radial-gradient(circle at 20% 20%, white 1px, transparent 1px)", backgroundSize: "24px 24px" }} />
      <div className="relative mx-auto max-w-3xl px-5 pt-8 pb-10 text-primary-foreground">
        <div className="flex items-center gap-2 text-sm opacity-90">
          <Leaf className="h-4 w-4" />
          <span>نماء — NAMAA</span>
        </div>
        <div className="mt-5 flex items-center gap-4">
          <div className="relative">
            <div className="absolute -inset-1 rounded-full" style={{ background: "var(--namaa-gold)", opacity: 0.5, filter: "blur(8px)" }} />
            <img
              src={engineerPhoto}
              alt="المهندس عزالدين الغراسي"
              className="relative h-24 w-24 rounded-full object-cover ring-4"
              style={{ borderColor: "var(--namaa-gold)", boxShadow: "var(--shadow-soft)" }}
            />
          </div>
          <div className="flex-1">
            <h1 className="text-xl font-bold leading-tight">المهندس عزالدين الغراسي</h1>
            <p className="mt-1 text-sm opacity-90">خبير وقاية النبات</p>
            <p className="mt-1 flex items-center gap-1 text-xs opacity-80">
              <BookOpen className="h-3 w-3" /> مؤلف كتاب «سحر الشخصية»
            </p>
          </div>
        </div>
      </div>
    </header>
  );
}

function WeatherCard({ onWeather }: { onWeather: (w: Weather | null) => void }) {
  const [w, setW] = useState<Weather | null>(null);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    const load = async (lat: number, lon: number, city: string) => {
      try {
        const r = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m`);
        const d = await r.json();
        const next = {
          temp: Math.round(d.current.temperature_2m),
          humidity: d.current.relative_humidity_2m,
          wind: Math.round(d.current.wind_speed_10m),
          code: d.current.weather_code,
          city,
        };
        setW(next);
        onWeather(next);
      } catch {
        setErr("تعذر تحميل بيانات الطقس");
      }
    };
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (p) => load(p.coords.latitude, p.coords.longitude, "موقعك"),
        () => load(24.7136, 46.6753, "الرياض"),
        { timeout: 5000 }
      );
    } else {
      load(24.7136, 46.6753, "الرياض");
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <Card className="overflow-hidden border-0 p-0" style={{ boxShadow: "var(--shadow-soft)" }}>
      <div className="flex items-center justify-between p-5" style={{ background: "var(--gradient-hero)", color: "var(--primary-foreground)" }}>
        <div>
          <div className="flex items-center gap-2 text-xs opacity-90">
            <Sun className="h-4 w-4" />
            <span>الطقس الآن</span>
          </div>
          <div className="mt-2 text-4xl font-bold">{w ? `${w.temp}°` : "—"}</div>
          <div className="text-sm opacity-90">{w ? `${weatherInfo(w.code).label} • ${w.city}` : err ?? "جارٍ التحميل..."}</div>
        </div>
        {w && (() => {
          const { Icon } = weatherInfo(w.code);
          return <Icon className="h-16 w-16 opacity-90" />;
        })()}
      </div>
      {w && (
        <div className="grid grid-cols-2 divide-x divide-border bg-card text-card-foreground" dir="ltr">
          <div className="flex items-center justify-center gap-2 p-3 text-sm" dir="rtl">
            <Droplets className="h-4 w-4 text-primary" />
            <span>رطوبة {w.humidity}%</span>
          </div>
          <div className="flex items-center justify-center gap-2 p-3 text-sm" dir="rtl">
            <Wind className="h-4 w-4 text-primary" />
            <span>رياح {w.wind} كم/س</span>
          </div>
        </div>
      )}
    </Card>
  );
}

function WeatherTips({ weather }: { weather: Weather | null }) {
  const tips = getTips(weather);
  if (!tips.length) return null;
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2">
        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
          <Leaf className="h-5 w-5 text-primary" />
        </div>
        <div>
          <h2 className="font-bold">نصائح زراعية بناءً على الجو</h2>
          <p className="text-xs text-muted-foreground">توصيات يومية حسب حالة الطقس في موقعك</p>
        </div>
      </div>
      <ul className="mt-4 space-y-2">
        {tips.map((t, i) => (
          <li key={i} className="rounded-lg bg-primary/5 px-3 py-2 text-sm leading-relaxed text-foreground">
            🌱 {t}
          </li>
        ))}
      </ul>
    </Card>
  );
}

type OpType = "ري" | "تسميد" | "مكافحة";
type LogEntry = { id: string; type: OpType; date: string; cost: number; notes?: string };

function FarmLog() {
  const [entries, setEntries] = useState<LogEntry[]>([]);
  const [type, setType] = useState<OpType>("ري");
  const [date, setDate] = useState<string>(() => new Date().toISOString().slice(0, 10));
  const [cost, setCost] = useState<string>("");
  const [notes, setNotes] = useState<string>("");

  useEffect(() => {
    try {
      const raw = localStorage.getItem(LOG_KEY);
      if (raw) setEntries(JSON.parse(raw));
    } catch {}
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(LOG_KEY, JSON.stringify(entries));
    } catch {}
  }, [entries]);

  const add = (e: React.FormEvent) => {
    e.preventDefault();
    const c = Number(cost);
    if (!date || Number.isNaN(c) || c < 0) {
      toast.error("الرجاء التأكد من التاريخ والتكلفة");
      return;
    }
    setEntries((prev) => [
      { id: crypto.randomUUID(), type, date, cost: c, notes: notes.trim() || undefined },
      ...prev,
    ]);
    setCost("");
    setNotes("");
    toast.success("تمت إضافة العملية للسجل");
  };

  const remove = (id: string) => setEntries((prev) => prev.filter((x) => x.id !== id));
  const total = entries.reduce((s, x) => s + x.cost, 0);

  return (
    <Card className="p-5">
      <div className="flex items-center gap-2">
        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
          <ClipboardList className="h-5 w-5 text-primary" />
        </div>
        <div>
          <h2 className="font-bold">السجل الزراعي</h2>
          <p className="text-xs text-muted-foreground">سجّل عمليات الري والتسميد والمكافحة وتكاليفها</p>
        </div>
      </div>

      <form onSubmit={add} className="mt-5 space-y-4">
        <div>
          <Label>نوع العملية</Label>
          <Select value={type} onValueChange={(v) => setType(v as OpType)}>
            <SelectTrigger className="mt-1.5"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="ري">ري</SelectItem>
              <SelectItem value="تسميد">تسميد</SelectItem>
              <SelectItem value="مكافحة">مكافحة</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>التاريخ</Label>
            <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="mt-1.5" required />
          </div>
          <div>
            <Label>التكلفة (ر.س)</Label>
            <Input type="number" min="0" step="0.01" inputMode="decimal" value={cost} onChange={(e) => setCost(e.target.value)} placeholder="0.00" className="mt-1.5" required />
          </div>
        </div>
        <div>
          <Label>ملاحظات (اختياري)</Label>
          <Input value={notes} onChange={(e) => setNotes(e.target.value)} maxLength={140} placeholder="مثال: رش وقائي للأشجار" className="mt-1.5" />
        </div>
        <Button type="submit" className="w-full" size="lg">
          <Sprout className="ml-2 h-4 w-4" />
          إضافة للسجل
        </Button>
      </form>

      <div className="mt-5">
        <div className="mb-3 flex items-center justify-between text-sm">
          <span className="font-semibold">العمليات المسجلة ({entries.length})</span>
          <span className="text-muted-foreground">الإجمالي: <span className="font-semibold text-foreground">{total.toFixed(2)} ر.س</span></span>
        </div>

        {entries.length === 0 ? (
          <p className="rounded-lg bg-muted/50 py-6 text-center text-sm text-muted-foreground">لا توجد عمليات بعد.</p>
        ) : (
          <ul className="space-y-2">
            {entries.map((e) => (
              <li key={e.id} className="flex items-center justify-between rounded-lg border bg-card p-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="rounded-full bg-primary/10 px-2.5 py-0.5 text-xs font-semibold text-primary">{e.type}</span>
                    <span className="text-xs text-muted-foreground">{e.date}</span>
                  </div>
                  {e.notes && <p className="mt-1 text-sm text-foreground/80">{e.notes}</p>}
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-sm font-semibold">{e.cost.toFixed(2)} ر.س</span>
                  <button onClick={() => remove(e.id)} className="text-muted-foreground hover:text-destructive" aria-label="حذف">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </Card>
  );
}

function FertilizerCalc() {
  const [crop, setCrop] = useState("tomato");
  const [area, setArea] = useState("1");
  const [areaUnit, setAreaUnit] = useState("dunum");
  const [fert, setFert] = useState("npk_15");
  const [result, setResult] = useState<null | { kg: number; bags: number; nutrient: string }>(null);

  const calc = () => {
    const a = parseFloat(area);
    if (!a || a <= 0) return;
    const hectares = areaUnit === "hectare" ? a : a / 10;
    const rate = CROP_RATES[crop];
    const f = FERT[fert];
    const elements = [
      { key: "N", need: rate.N, pct: f.n },
      { key: "P", need: rate.P, pct: f.p },
      { key: "K", need: rate.K, pct: f.k },
    ].filter((e) => e.pct > 0);
    if (!elements.length) return;
    const main = elements.reduce((a, b) => (b.pct > a.pct ? b : a));
    const kgTotal = (main.need * hectares) / main.pct;
    setResult({ kg: Math.round(kgTotal), bags: Math.ceil(kgTotal / 50), nutrient: main.key });
  };

  return (
    <Card className="p-5">
      <div className="flex items-center gap-2">
        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
          <Calculator className="h-5 w-5 text-primary" />
        </div>
        <div>
          <h2 className="font-bold">حاسبة معدل التسميد</h2>
          <p className="text-xs text-muted-foreground">احسب كمية السماد المطلوبة بدقة هندسية</p>
        </div>
      </div>

      <div className="mt-5 space-y-4">
        <div>
          <Label>نوع المحصول</Label>
          <Select value={crop} onValueChange={setCrop}>
            <SelectTrigger className="mt-1.5"><SelectValue /></SelectTrigger>
            <SelectContent>
              {Object.entries(CROP_RATES).map(([k, v]) => (
                <SelectItem key={k} value={k}>{v.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>المساحة</Label>
            <Input type="number" min="0" step="0.1" value={area} onChange={(e) => setArea(e.target.value)} className="mt-1.5" />
          </div>
          <div>
            <Label>الوحدة</Label>
            <Select value={areaUnit} onValueChange={setAreaUnit}>
              <SelectTrigger className="mt-1.5"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="dunum">دونم</SelectItem>
                <SelectItem value="hectare">هكتار</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div>
          <Label>نوع السماد</Label>
          <Select value={fert} onValueChange={setFert}>
            <SelectTrigger className="mt-1.5"><SelectValue /></SelectTrigger>
            <SelectContent>
              {Object.entries(FERT).map(([k, v]) => (
                <SelectItem key={k} value={k}>{v.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <Button onClick={calc} className="w-full" size="lg">
          <Sprout className="ml-2 h-4 w-4" />
          احسب الكمية
        </Button>

        {result && (
          <div className="rounded-xl border-2 border-primary/20 bg-primary/5 p-4 text-center">
            <div className="text-xs text-muted-foreground">الكمية المطلوبة (محسوبة على عنصر {result.nutrient})</div>
            <div className="mt-1 text-3xl font-bold text-primary">{result.kg.toLocaleString("ar")} كجم</div>
            <div className="mt-1 text-sm text-muted-foreground">≈ {result.bags} كيس (50 كجم)</div>
          </div>
        )}
      </div>
    </Card>
  );
}

function Consult() {
  const [crop, setCrop] = useState("");
  const [problem, setProblem] = useState("");

  const send = () => {
    const text = `السلام عليكم مهندس عزالدين،\n\nالمحصول: ${crop || "—"}\nالمشكلة: ${problem || "—"}\n\nأرجو الاستشارة. شكراً.`;
    const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`;
    window.open(url, "_blank");
  };

  return (
    <Card className="p-5">
      <div className="flex items-center gap-2">
        <div className="flex h-10 w-10 items-center justify-center rounded-full" style={{ background: "oklch(0.7 0.18 145 / 0.15)" }}>
          <MessageCircle className="h-5 w-5" style={{ color: "oklch(0.55 0.18 145)" }} />
        </div>
        <div>
          <h2 className="font-bold">استشارة فورية</h2>
          <p className="text-xs text-muted-foreground">تواصل مباشر عبر واتساب</p>
        </div>
      </div>

      <div className="mt-5 space-y-4">
        <div>
          <Label>نوع المحصول</Label>
          <Input value={crop} onChange={(e) => setCrop(e.target.value)} placeholder="مثال: طماطم محمية" className="mt-1.5" />
        </div>
        <div>
          <Label>تفاصيل المشكلة</Label>
          <Textarea value={problem} onChange={(e) => setProblem(e.target.value)} placeholder="اوصف الأعراض، عمر النبات، نوع التربة..." rows={4} className="mt-1.5" />
        </div>
        <Button onClick={send} className="w-full" size="lg" style={{ background: "oklch(0.55 0.18 145)", color: "white" }}>
          <MessageCircle className="ml-2 h-5 w-5" />
          إرسال عبر واتساب
        </Button>
        <a href={`tel:+${WHATSAPP_NUMBER}`} className="flex items-center justify-center gap-2 text-sm text-muted-foreground hover:text-primary">
          <Phone className="h-4 w-4" />
          <span dir="ltr">+{WHATSAPP_NUMBER}</span>
        </a>
      </div>
    </Card>
  );
}

function AdvisoryCenter() {
  const [name, setName] = useState("");
  const [question, setQuestion] = useState("");

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !question.trim()) {
      toast.error("الرجاء تعبئة الاسم والسؤال");
      return;
    }
    toast.success("تم استلام استشارتك بنجاح، وسيتم الرد من قبل المهندس عزالدين الغراسي قريباً");
    setName("");
    setQuestion("");
  };

  return (
    <Card className="p-5">
      <div className="flex items-center gap-2">
        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
          <Headphones className="h-5 w-5 text-primary" />
        </div>
        <div>
          <h2 className="font-bold">مركز الاستشارات الزراعية</h2>
          <p className="text-xs text-muted-foreground">أرسل سؤالك وسيصلك الرد قريباً</p>
        </div>
      </div>

      <form onSubmit={submit} className="mt-5 space-y-4">
        <div>
          <Label>اسم المزارع</Label>
          <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="الاسم الكامل" className="mt-1.5" />
        </div>
        <div>
          <Label>سؤالك</Label>
          <Textarea value={question} onChange={(e) => setQuestion(e.target.value)} placeholder="اكتب استشارتك هنا..." rows={4} className="mt-1.5" />
        </div>
        <Button type="submit" size="lg" className="w-full text-base font-bold">
          <Send className="ml-2 h-5 w-5" />
          إرسال الاستشارة للمهندس عزالدين
        </Button>
      </form>
    </Card>
  );
}

function Index() {
  const [weather, setWeather] = useState<Weather | null>(null);
  return (
    <div dir="rtl" className="min-h-screen bg-background font-sans">
      <Toaster richColors position="top-center" dir="rtl" />
      <Header />
      <main className="mx-auto max-w-3xl space-y-5 px-4 py-6 pb-12">
        <WeatherCard onWeather={setWeather} />
        <WeatherTips weather={weather} />
        <FarmLog />
        <FertilizerCalc />
        <Consult />
        <AdvisoryCenter />
        <footer className="pt-4 text-center text-xs text-muted-foreground">
          © نماء — جميع الحقوق محفوظة للمهندس عزالدين الغراسي
        </footer>
      </main>
    </div>
  );
}
